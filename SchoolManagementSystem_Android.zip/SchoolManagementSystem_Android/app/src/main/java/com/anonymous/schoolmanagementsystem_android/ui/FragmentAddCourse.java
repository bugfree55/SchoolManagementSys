package com.anonymous.schoolmanagementsystem_android.ui;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.anonymous.schoolmanagementsystem_android.R;
import com.anonymous.schoolmanagementsystem_android.authentication.Main;

public final class FragmentAddCourse extends Fragment {

    Button buttonAddCourse;
    EditText editTextCourse;
    Spinner spinnerDepartment;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fra_add_course, container,false);
        initialize(view);
        return view;
    }

    public void initialize(View view)
    {
        buttonAddCourse = view.findViewById(R.id.buttonAddCourse);
        editTextCourse = view.findViewById(R.id.editTextCourseName);
        spinnerDepartment = view.findViewById(R.id.spinnerFaculty);
        buttonAddCourse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String courseName = editTextCourse.getText().toString().trim();
                if(courseName.equals(""))
                {
                    editTextCourse.setBackgroundColor(Color.RED);//required
                    Toast.makeText(getContext(),"Course name cannot be empty", Toast.LENGTH_SHORT).show();
                    return;
                }

                String departmentName = spinnerDepartment.getSelectedItem().toString().trim();
                if(departmentName.equals(""))
                {
                    spinnerDepartment.setBackgroundColor(Color.RED);
                    Toast.makeText(getContext(),"Department cannot be none", Toast.LENGTH_SHORT).show();
                }
                //else its successful
                Toast.makeText(getContext(),"Course Added Successfully", Toast.LENGTH_SHORT).show();
                //Main.AddCourse();
            }
        });

    }
}
