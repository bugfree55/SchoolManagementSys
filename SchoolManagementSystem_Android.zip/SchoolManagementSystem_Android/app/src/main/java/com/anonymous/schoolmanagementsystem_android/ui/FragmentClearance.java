package com.anonymous.schoolmanagementsystem_android.ui;

import androidx.fragment.app.Fragment;

public final class FragmentClearance extends Fragment {
}
