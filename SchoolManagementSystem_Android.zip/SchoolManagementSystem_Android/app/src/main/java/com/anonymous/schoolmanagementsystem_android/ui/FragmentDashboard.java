package com.anonymous.schoolmanagementsystem_android.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.anonymous.schoolmanagementsystem_android.MainActivity;
import com.anonymous.schoolmanagementsystem_android.R;

public class FragmentDashboard extends Fragment {

    Button buttonAddCourse, buttonApplyCourse, buttonRegisterStudent, buttonClearStudent, buttonViewTranscript;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fra_dashboard, container,false);
        initialize(view);
        return view;
    }

    public void initialize(View view)
    {
        buttonAddCourse = view.findViewById(R.id.buttonAddCourse);
        buttonApplyCourse = view.findViewById(R.id.buttonApplyCourse);
        buttonClearStudent =  view.findViewById(R.id.buttonClearStudent);
        buttonRegisterStudent = view.findViewById(R.id.buttonRegisterStudent);
        buttonViewTranscript = view.findViewById(R.id.buttonViewTranscript);

        buttonAddCourse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.replaceFragment(new FragmentAddCourse());
            }
        });

        buttonViewTranscript.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //MainActivity.replaceFragment(new view.FragmentViewTranscript());
            }
        });

        buttonClearStudent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.replaceFragment(new FragmentClearance());
            }
        });

        buttonRegisterStudent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.replaceFragment(new FragmentRegisterPage());
            }
        });

        buttonApplyCourse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.replaceFragment(new FragmentApplyCourse());
            }
        });
    }
}
