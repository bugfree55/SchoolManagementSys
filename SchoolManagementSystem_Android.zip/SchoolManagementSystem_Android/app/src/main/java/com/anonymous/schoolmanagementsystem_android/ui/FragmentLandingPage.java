package com.anonymous.schoolmanagementsystem_android.ui;

import androidx.fragment.app.Fragment;

public class FragmentLandingPage extends Fragment {
}
