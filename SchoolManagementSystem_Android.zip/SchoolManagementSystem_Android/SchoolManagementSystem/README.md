# SchoolManagementSystem
 this is a school management system in android
